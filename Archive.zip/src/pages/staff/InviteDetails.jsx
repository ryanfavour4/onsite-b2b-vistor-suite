import React from 'react'

const InviteDetails = () => {
  return (
    <div>InviteDetails</div>
  )
}

export default InviteDetails