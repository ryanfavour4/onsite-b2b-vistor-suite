import VisitorsStatsCard from "../../components/cards/VisitorsStatsCard";
import VisitorsStatsPieChart from "../../components/charts/VisitorsStatsPieChart";
import { barChartsData, pieChartsData } from "../../data";
import VisitorsStatsBarChart from "../../components/charts/VisitorsStatsBarChart";
import VisitorsStatsLineChart from "../../components/charts/VisitorsStatsLineChart";

const visitorsStatsData = [
  { title: "Visitors in premises", value: 0 },
  { title: "Exits", value: 0 },
  { title: "Scheduled visits", value: 0 },
];

const visitorsStatsPerDay = [
  { day: "Yesterday", value: 3 },
  { day: "Today", value: 3 },
];

const Dashboard = () => {
  return (
    <div className="p-2 w-full z-0 relative">
      <div className="flex flex-wrap p-0 justify-center">
        <div className="bg-white text-dark p-4 shadow-lg mx-2 flex-1 border-solid border-[1px] border-light rounded-md capitalize sm:mt-0 mt-2">
          <h4 className="font-bold">Visitors</h4>
          <div>
            {visitorsStatsPerDay.map(({ day, value }) => {
              return (
                <div
                  className="flex items-center justify-between mt-3 min-w-max"
                  key={day}
                >
                  <p>{day}</p>
                  <p>{value}</p>
                </div>
              );
            })}
          </div>
        </div>

        {visitorsStatsData.map(({ value, title }) => {
          return <VisitorsStatsCard value={value} title={title} key={title} />;
        })}
      </div>

      <div className="flex flex-wrap mt-4 p-0 !capitalize">
        {pieChartsData.map(({ title, data }) => {
          return (
            <VisitorsStatsPieChart
              title={title}
              key={title}
              chartData={{
                labels: data.map(({ label }) => label),
                datasets: [
                  {
                    data: data.map(({ value }) => value),
                    backgroundColor: ["#604e9e", "#8B0000", "#0f6e17"],
                  },
                ],
              }}
            />
          );
        })}
      </div>

      <div className="w-full p-3">
        <div className="flex flex-1 mr-4 mt-4 flex-col lg:flex-row w-full justify-between">
          {
            <VisitorsStatsBarChart
              title={barChartsData[0].title}
              key={barChartsData[0].title}
              chartData={{
                labels: barChartsData[0].data.map(({ month }) => month),
                datasets: [
                  {
                    data: barChartsData[0].data.map(({ value }) => value[0]),
                    label: "Scheduled Visitors",
                    backgroundColor: ["#604e9e"],
                  },
                  {
                    data: barChartsData[0].data.map(({ value }) => value[1]),
                    label: "Unscheduled Visitors",
                    backgroundColor: "#8B0000",
                  },
                ],
              }}
            />
          }
          {
            <VisitorsStatsLineChart
              title={barChartsData[0].title}
              key={barChartsData[0].title}
              chartData={{
                labels: barChartsData[0].data.map(({ month }) => month),
                datasets: [
                  {
                    data: barChartsData[0].data.map(({ value }) => value[0]),
                    label: "Scheduled Visitors",
                    backgroundColor: ["#604e9e"],
                    lineTension: 0.5,
                    borderWidth: 1.5,
                    borderColor: "#604e9e",
                  },
                  {
                    data: barChartsData[0].data.map(({ value }) => value[1]),
                    label: "Unscheduled Visitors",
                    backgroundColor: "#8B0000",
                    lineTension: 0.5,
                    borderWidth: 1.5,
                    borderColor: "#8B0000",
                  },
                ],
              }}
            />
          }
        </div>

        <div className="flex flex-1 mr-4 mt-4 flex-col md:flex-row w-full justify-between">
          {
            <VisitorsStatsBarChart
              title={barChartsData[1].title}
              key={barChartsData[1].title}
              chartData={{
                labels: barChartsData[1].data.map(({ month }) => month),
                datasets: [
                  {
                    data: barChartsData[1].data.map(({ value }) => value[0]),
                    label: "Scheduled Visitors",
                    backgroundColor: ["#604e9e"],
                  },
                  {
                    data: barChartsData[1].data.map(({ value }) => value[1]),
                    label: "Unscheduled Visitors",
                    backgroundColor: "#8B0000",
                  },
                ],
              }}
            />
          }
          {
            <VisitorsStatsLineChart
              title={barChartsData[1].title}
              key={barChartsData[1].title}
              chartData={{
                labels: barChartsData[1].data.map(({ month }) => month),
                datasets: [
                  {
                    data: barChartsData[1].data.map(({ value }) => value[0]),
                    label: "Scheduled Visitors",
                    backgroundColor: ["#604e9e"],
                    lineTension: 0.5,
                    borderWidth: 1.5,
                    borderColor: "#604e9e",
                  },
                  {
                    data: barChartsData[1].data.map(({ value }) => value[1]),
                    label: "Unscheduled Visitors",
                    backgroundColor: "#8B0000",
                    lineTension: 0.5,
                    borderWidth: 1.5,
                    borderColor: "#8B0000",
                  },
                ],
              }}
            />
          }
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
