import React from "react";
import { useState } from "react";
import ReactQuill from "react-quill";
import MultiSelectSearchableDropdown from "../../components/dropdowns/MultiSelectSearchableDropdown";
import "react-quill/dist/quill.snow.css";

const ConfigureWelcomeMessage = () => {
  const [email, setEmail] = useState("");
  const [emailMessage, setEmailMessage] = useState("");
  const [attachment, setAttachment] = useState("");

  const [firstStaffs, setFirstStaffs] = useState([]);
  const [secondStaffs, setSecondStaffs] = useState([]);

  const handleSubmit = () => {
    //
  };
  return (
    <div className="">
      <h3 className="capitalize text-2xl font-semibold m-4 ml-10">
        Configure welcome message
      </h3>
      <div className="p-8 bg-white ml-10 rounded-md">
        <form className="w-4/5 block max-w-[500px]" onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="email" className="font-semibold text-black">
              Email Subject
            </label>
            <input
              type="email"
              value={email}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
            />
          </div>

          <div className="">
            <label htmlFor="emailMessage" className="font-semibold text-black">
              Email Message
            </label>
            <div className="mb-4 ">
            <ReactQuill
              theme="snow"
              value={emailMessage}
              onChange={setEmailMessage}
              style={{height: '100px', marginBottom: '60px'}}
            />
            </div>


          </div>

          <div className="mb-3">
            <label htmlFor="attachment" className="font-semibold text-black">
              Upload Attachment
            </label>
            <input
              type="file"
              value={attachment}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setAttachment(e.target.value)}
              placeholder="upload attachment"
            />
          </div>

          <div className=" mb-4">
            <label
              htmlFor="whatsappMessage"
              className="font-semibold text-black capitalize "
            >
              Enter whatsapp message
            </label>
            <textarea
              name=""
              id=""
              className="w-full bg-transparent border border-light rounded-md outline-0 p-2 h-32"
            ></textarea>
          </div>

          <h4 className="text-xl font-semibold">Also notify these Persons:</h4>

          <div>
            {[
              {
                selectedOptions: firstStaffs,
                setSelectedOptions: setFirstStaffs,
                options: [
                  { title: "lorem", id: "jks" },
                  { title: "ipsum", id: "ddd" },
                  { title: "dolor", id: "ii" },
                ],
              },
              {
                selectedOptions: secondStaffs,
                setSelectedOptions: setSecondStaffs,
                options: [
                  { title: "lorem", id: "jks" },
                  { title: "ipsum", id: "ddd" },
                  { title: "dolor", id: "ii" },
                ],
              },
            ].map(({ options, selectedOptions, setSelectedOptions }) => (
              <div className="mt-4">
                <p className="my-1">Select Staff:</p>
                <MultiSelectSearchableDropdown
                  options={options}
                  selectedOptions={selectedOptions}
                  setSelectedOptions={setSelectedOptions}
                />
                <label htmlFor="useStaff">
                  <input type="checkbox" name="" id="" />{" "}
                  <span>Use Staff List</span>
                </label>
              </div>
            ))}
          </div>

          <button
            type="submit"
            className="w-max px-6 bg-blue py-3 rounded-md text-white hover:bg-blue text-lg mt-3"
            onClick={handleSubmit}
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default ConfigureWelcomeMessage;
