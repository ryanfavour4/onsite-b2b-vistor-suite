import { useState } from "react";
import Table from "../../components/tables/Table";
import { blacklistData, messagingData } from "../../data";
import { useNavigate } from "react-router-dom";
import AddPurposeModal from "../../components/modals/AddPurposeModal";
import Loading from "../../components/Loading";
import Error from "../../components/Error";
import useFetch from "../../hooks/useFetch";
import EditPurposeModal from "../../components/modals/EditPurpose";
import DeleteStaffModal from "../../components/modals/DeleteStaffModal";
import DeletePurposeModal from "../../components/modals/DeletePurposeModal";
import DisablePurposeModal from "../../components/modals/DisablePurposeModal";

const Messaging = () => {
  const [showAddPurposeModal, setShowAddPurposeModal] = useState(false);
  const [showEditPurposeModal, setShowEditPurposeModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showDisableModal, setShowDisableModal] = useState(false);
  const [id, setId] = useState(0)


  const [refresh, setRefresh] = useState(false)

  const navigate = useNavigate();

  const viewMessage = (inviteId) => {
    navigate(`/invites/${inviteId}`);
  };



  const editMessage = (inviteId) => {
    setShowEditPurposeModal(true)
    setId(inviteId.id)



  };

  const deleteMessage = (data) => {
    setId(data.id)
    setShowDeleteModal(true)
  };

  const disableMessage = (data) => {

    setId(data.id)
    setShowDisableModal(true)

  }

  const configureMessage = () => {
    navigate(`/configure-welcome-message`);
  };

  const actionColItems = [
    { title: "view message", func: (inviteId) => viewMessage(inviteId) },
    { title: "edit", func: (inviteId) => editMessage(inviteId) },
    // { title: "delete message", func: (id) => deleteMessage(id) },
    { title: "configure welcome message", func: configureMessage },
    { title: "delete", func: (inviteId) => deleteMessage(inviteId) },
    { title: "disable/enable", func: (inviteId) => disableMessage(inviteId) },


  ];

  const { loading, error, data } = useFetch("/settings/visit-purpose", [refresh]);

  if (loading) {
    return <Loading />;
  }

  if (error) {
    return <Error message={error?.message} />;
  }

  return (
    <div className="p-4">
      <Table
        data={data.data}
        headings={['purpose name', 'purpose label', 'purpose type', 'is enabled', 'is default', 'action']}
        fieldsKeys={['visit_purpose_name', 'visit_purpose_label', 'field_type', 'is_enabled', 'is_default', 'action']}
        actionColDropdownItems={actionColItems}
        title={"Messaging"}
        tableTitle={"Purpose of visit"}
      >
        <button
          onClick={() => setShowAddPurposeModal(true)}
          className="mx-2 bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 mt-2../"
        >
          Add new purpose
        </button>
      </Table>

      <AddPurposeModal
        showModal={showAddPurposeModal}
        setShowModal={setShowAddPurposeModal}
        refresh={refresh}
        setRefresh={setRefresh}
      />


      <EditPurposeModal
        showModal={showEditPurposeModal}
        setShowModal={setShowEditPurposeModal}
        refresh={refresh}
        setRefresh={setRefresh}
        id={id}


      />


      <DeletePurposeModal
        showModal={showDeleteModal}
        setShowModal={setShowDeleteModal}
        id={id}

      />



      <DisablePurposeModal
        showModal={showDisableModal}
        setShowModal={setShowDisableModal}
        id={id}

      />
    </div>
  );
};

export default Messaging;
