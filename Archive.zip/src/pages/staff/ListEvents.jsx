import React from 'react'
import { useState } from 'react'
import Error from '../../components/Error'
import Loading from '../../components/Loading'
import CreateEventModal from '../../components/modals/CreateEventModal'
import Table from '../../components/tables/Table'
import { listEventsData } from '../../data'
import useFetch from '../../hooks/useFetch'

const ListEvents = () => {
  const [showModal, setShowModal] = useState(false)
  const [refresh, setRefresh] = useState(false)

  const viewVisitor = (visitorId) => {
    navigate(`/visitor-log/${visitorId}`)
  };

  const editVisitor = () => {
    setShowEditModal(true);
    //
  };

  const deleteVisitor = () => {
    console.log("export to csv");
  };

  const viewAttendees = () => {
    // 
  }

  const actionColItems = [
    { title: "view", func: (visitorId) => viewVisitor(visitorId) },
    { title: "edit", func: editVisitor },
    { title: "delete", func: deleteVisitor },
    { title: "view attendees", func: viewAttendees },
  ];

  const { loading, error, data } = useFetch("events/get/events", [refresh]);

  if (loading) {
    return <Loading />
  }

  if (error) {
    return <Error message={error?.message} />;
  }


  return (
    <div className='p-4'>
      <Table
        data={data.data.rows}
        headings={['event name', 'event ID', 'event date', 'location', 'action']}
        fieldsKeys={['event_name', 'event_id', 'start', 'location', 'action']}
        actionColDropdownItems={actionColItems}
        title={"List events"}
      >
        <button onClick={() => setShowModal(true)} className="bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 mt-2 mb-4 capitalize">
          create event
        </button>
      </Table>

      <CreateEventModal showModal={showModal} setShowModal={setShowModal} refresh={refresh} setRefresh={setRefresh} />
    </div>
  )
}

export default ListEvents