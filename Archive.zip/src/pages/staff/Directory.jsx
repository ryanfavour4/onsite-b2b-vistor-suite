import Table from "../../components/tables/Table";
import { blacklistData } from "../../data";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Loading from "../../components/Loading";
import Error from "../../components/Error";
import useFetch from "../../hooks/useFetch";
import { Api } from "../../axios";
import BlacklistVisitorModal from "../../components/modals/BlacklistVisitorModal";
import RegisterVisitorModal from "../../components/modals/RegisterVisitorModal";
import AddDirectoryModal from "../../components/modals/AddDirectoryModal";

const Directory = () => {
  const [signedInVisitors, setSignedInVisitors] = useState("");
  const [purpose, setPurpose] = useState("");
  const [selectHost, setSelectHost] = useState("");
  const [selectLocation, setSelectLocation] = useState("");
  const [displayFilters, setDisplayFilters] = useState(false);
  const [showActionDropdown, setShowActionDropdown] = useState(false);
  const [selected, setSelected] = useState(null)
  const [showBlacklistModal, setShowBlacklistModal] = useState(false);
  const [showRegModal, setShowRegModal] = useState(false);
  const [refresh, setRefresh] = useState(false);



  const navigate = useNavigate();

  const filterItems = [
    {
      searchState: signedInVisitors,
      stateModifier: setSignedInVisitors,
      title: "signed in visitors",
      options: ["lorem", "ipsum", "dolor"],
    },
    {
      searchState: purpose,
      stateModifier: setPurpose,
      title: "purpose",
      options: ["lorem", "ipsum", "dolor"],
    },
    {
      searchState: selectHost,
      stateModifier: setSelectHost,
      title: "select host",
      options: ["lorem", "ipsum", "dolor"],
    },
    {
      searchState: selectLocation,
      stateModifier: setSelectLocation,
      title: "select location",
      options: ["lorem", "ipsum", "dolor"],
    },
  ];

  const viewProfile = (visitorId) => {
    navigate(`/visitor-log/${visitorId}`);
  };

  const viewVisitationHistory = (visitorId) => {
    navigate(`/visitor-log/${visitorId}`);
  };

  const exportToCSV = () => {
    console.log("export to csv");
  };

  const bulkDelete = () => {
    console.log("bulk delete");
  };

  const blacklistVisitor = (data) => {
    console.log(data, 'blacklist details data')
    setSelected(data)
    setShowBlacklistModal(true);
  };


  const sendEmail = () => {
    // console.log("bulk delete");
  };

  const actionColItems = [
    { title: "view profile", func: (visitorId) => viewProfile(visitorId) },
    {
      title: "visitation history",
      func: (visitorId) => viewVisitationHistory(visitorId),
    },
    { title: "add to blacklist", func: (data) => blacklistVisitor(data) },
  ];

  const topDropdownItems = [
    {
      title: "export to csv",
      func: exportToCSV,
      icon: <i className="fa-solid fa-file-export"></i>,
    },
    {
      title: "bulk delete",
      func: bulkDelete,
      icon: <i className="fa-solid fa-trash"></i>,
    },
    {
      title: "send email",
      func: sendEmail,
      icon: <i class="fa-solid fa-envelope"></i>,
    },
  ];

  const { loading, error, data } = useFetch("visitor/directory", []);

  if (loading) {
    return <Loading />;
  }

  if (error != "") {
    return <Error message={error?.message} />;
  }

  return (
    <div className="p-4">
      <button
        onClick={() => setShowRegModal(true)}
        className="bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 mt-2 mb-4"
      >
        Add Directory <i className="fa-solid fa-address-card ml-2"></i>
      </button>
      <Table
        data={data.data.rows}
        headings={[
          // "branch ID",
          // "branch code",
          "name",
          "phone number",
          "email",
          "branch code",
          // "type",
          // "company",
          "action"
        ]}
        fieldsKeys={[
          // "id",
          // "branch_code",
          "name",
          "phone",
          "email",
          "branch_code",
          // "type",
          // "company",
          "action"
        ]}
        filterItems={filterItems}
        actionColDropdownItems={actionColItems}
        topDropdownItems={topDropdownItems}
        displayFilters={displayFilters}
        setDisplayFilters={setDisplayFilters}
        showActionDropdown={showActionDropdown}
        setShowActionDropdown={setShowActionDropdown}
        title={"Directory"}
      />



      <BlacklistVisitorModal
        showModal={showBlacklistModal}
        setShowModal={setShowBlacklistModal}
        selected={selected}
        setSelected={setSelected}
      />


      <AddDirectoryModal
        showModal={showRegModal}
        setShowModal={setShowRegModal}
        refresh={refresh}
        setRefresh={setRefresh}
      />
    </div>
  );
};

export default Directory;
