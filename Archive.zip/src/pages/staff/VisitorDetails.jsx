import { useParams } from "react-router-dom"
import Summary from "../../components/tabs/tab-contents/visitor-tab-contents/Summary"
import VisitationHistory from "../../components/tabs/tab-contents/visitor-tab-contents/VisitationHistory"
import Tabs from "../../components/tabs/Tabs"

const VisitorDetails = () => {
    const {visitorId} = useParams()

  const tabTitles = ['summary', 'visitation history']
  const tabContents =  [<Summary visitorId={visitorId} />, <VisitationHistory />]

  return (
    <div className="p-2">
      <p>
        Visitor details for {visitorId}
      </p>
      <Tabs tabTitles={tabTitles} tabContents={tabContents} />
    </div>
  )
}

export default VisitorDetails