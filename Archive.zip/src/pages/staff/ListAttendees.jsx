import React, { useEffect } from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import SearchableDropdown from "../../components/dropdowns/SearchableDropdown";
import Error from "../../components/Error";
import Loading from "../../components/Loading";
import CreateEventModal from "../../components/modals/CreateEventModal";
import RegisterAttendeeModal from "../../components/modals/RegisterAttendeeModal";
import Table from "../../components/tables/Table";
import { listAttendeesData } from "../../data";
import useFetch from "../../hooks/useFetch";

const ListAttendees = () => {
  const [event, setEvent] = useState({});


  const { data, loading, error } = useFetch(`events/get-all-attendees?page=1&eventId=${event.value}`, [event])

  console.log(data, 'attendees data')
  const [showModal, setShowModal] = useState(false);
  const [displayFilters, setDisplayFilters] = useState(false);

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const [events, setEvents] = useState([]);

  const navigate = useNavigate()

  const eventOptions = useFetch('events/get/events', [])


  const viewProfile = (visitorId) => {
    navigate(`/visitor-log/${visitorId}`);
  };

  const editProfile = () => {
    // setShowEditModal(true);
    //
  };

  const deleteProfile = () => {
    console.log("export to csv");
  };

  const actionColItems = [
    { title: "view", func: (visitorId) => viewProfile(visitorId) },
    { title: "edit", func: editProfile },
    { title: "delete", func: deleteProfile },
  ];

  const filterItems = [
    {
      searchState: startDate,
      stateModifier: setStartDate,
      title: "Select start date",
      options: [
        "Tues, 13th December 2022", "Tues, 13th December 2022", "Tues, 13th December 2022"
      ],
    },
    {
      searchState: endDate,
      stateModifier: setEndDate,
      title: "Select end date",
      options: ["Tues, 13th December 2022", "Tues, 13th December 2022", "Tues, 13th December 2022"],
    },
    {
      searchState: event,
      stateModifier: setEvent,
      title: "select event",
      options: ["lorem", "ipsum", "dolor"],
    },
  ];

  useEffect(() => {
    // console.log(locationOptions.data, 'location dataaa')
    setEvents(eventOptions.data?.data?.rows?.map(
      ({ event_id, event_name }) => ({ value: event_id, label: event_name }
      )))
    console.log(data);


  }, [eventOptions.data])

  // if (true) {
  //   return (
  //     <div>
  //       <button
  //         onClick={() => setShowModal(true)}
  //         className="bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 mt-2 mb-4"
  //       >
  //         Register Attendee
  //       </button>
  //       <RegisterAttendeeModal
  //         showModal={showModal}
  //         setShowModal={setShowModal}
  //       />
  //     </div>
  //   )
  // }


  console.log(data?.Data);

  return (
    <div className="p-4">

      <div className="mb-3 w-max">
        <label htmlFor="invitedBy" className="font-semibold text-black ">
          Select Event
        </label>
        <SearchableDropdown
          loading={eventOptions.loading}
          options={events}
          selectedOption={event}
          setSelectedOption={setEvent}
          transparent={true}
        />
      </div>

      {
        loading ?
          <Loading />
          :
          error ?
            <Error message={error?.message} />
            :
            <Table
              data={data.Data}
              headings={[
                "first name",
                "last name",
                "phone",
                "email",
                "registrationDate",
                "registrationId",
                "signIn",
                "action",]
              }
              fieldsKeys={[
                'first_name',
                'last_name',
                'phone_number',
                'email',
                'createdAt',
                'uuid',
                'checked_in',
                'action',
              ]}
              actionColDropdownItems={actionColItems}
              displayFilters={displayFilters}
              setDisplayFilters={setDisplayFilters}
              title={"List attendees"}
              filterItems={filterItems}
            >

              <button
                onClick={() => setShowModal(true)}
                className="bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 mt-2 mb-4"
              >
                Register Attendee
              </button>
            </Table>
      }


      <RegisterAttendeeModal
        showModal={showModal}
        setShowModal={setShowModal}
      />
    </div>
  );
};

export default ListAttendees;
