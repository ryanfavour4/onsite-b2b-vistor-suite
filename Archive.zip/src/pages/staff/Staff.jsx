import { useState } from "react";
import RegisterStaffModal from "../../components/modals/RegisterStaffModal";
import SearchableDropdown from "../../components/dropdowns/SearchableDropdown";
import StaffCard from "../../components/cards/StaffCard";
import { staffsData } from "../../data";
import DeleteStaffModal from "../../components/modals/DeleteStaffModal";
import EditStaffModal from "../../components/modals/EditStaffModal";
import DisableStaffModal from "../../components/modals/DisableStaffModal";
import TableActionDropdown from "../../components/dropdowns/TableActionDropdown";
import useFetch from "../../hooks/useFetch";
import Error from "../../components/Error";
import Loading from "../../components/Loading";
import avatar from "../../assets/defaultAvatar.png";
import { useEffect } from "react";
import { Api } from "../../axios";

const Staff = () => {
  const [displayFilters, setDisplayFilters] = useState(false);
  const [showRegModal, setShowRegModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  const [refresh, setRefresh] = useState(false)

  const [department, setDepartment] = useState("");
  const [location, setLocation] = useState("");
  const [availability, setAvailability] = useState("");
  const [inviteOnlyMode, setInviteOnlyMode] = useState('');

  const [searchTerm, setSearchTerm] = useState("");

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [staffID, setStaffID] = useState(0);


  const [showDisableModal, setShowDisableModal] = useState(false);

  const { data, loading, error } = useFetch("settings/get-all-staffs", [refresh]);



  console.log(data)

  // useEffect(() => {

  //   try {

  //     const data = async () => {
  //       await Api.get("settings/get-all-staffs").then((res) => {
  //         console.log(res);
  //       })
  //     }

  //     data()

  //   } catch (error) {

  //     console.log(error);

  //   }

  // })

  const exportToCSV = () => {
    console.log("export to csv");
  };

  const sendEmail = () => {
    // console.log("bulk delete");
  };

  const [allDepts, setAllDepts] = useState([])


  useEffect(() => {
    try {

      const fetchDept = async () => {

        await Api.get("settings/get-department").then((res) => {

          res.data?.data.map((e) => {
            console.log(e);
          })
          res.data?.data?.map((e, i) => {
            setAllDepts(e)
            console.log(e);

          })

        })
      }


      fetchDept()

    } catch (error) {

      console.log(error);

    }
  })

  console.log(allDepts);


  const departmentOptions = [
    { value: 1, label: 'lorem' },
    { value: 2, label: 'ipsum' },
    { value: 3, label: 'dolor' }
  ];

  const locationOptions = [
    { value: 1, label: 'lorem' },
    { value: 2, label: 'ipsum' },
    { value: 3, label: 'dolor' }
  ];

  const availabilityOptions = [
    { value: 1, label: 'available' },
    { value: 2, label: 'not available' }
  ];

  const inviteOnlyModeOptions = [
    { value: true, label: 'active' },
    { value: false, label: 'inactive' }
  ];

  const filterItems = [
    {
      searchState: department,
      stateModifier: setDepartment,
      title: "select department",
      options: allDepts?.department
    },
    {
      searchState: location,
      stateModifier: setLocation,
      title: "select location",
      options: locationOptions,
    },
    {
      searchState: availability,
      stateModifier: setAvailability,
      title: "select availability",
      options: availabilityOptions,
    },
    {
      searchState: inviteOnlyMode,
      stateModifier: setInviteOnlyMode,
      title: "select invite only mode",
      options: inviteOnlyModeOptions,
    },
  ];



  // const filterItems = [
  //   {
  //     searchState: department,
  //     stateModifier: setDepartment,
  //     title: "select department",
  //     options: [{ value: 1, label: 'lorem' }, { value: 2, label: 'ipsum' }, { value: 3, label: 'dolor' }],
  //   },
  //   {
  //     searchState: location,
  //     stateModifier: setLocation,
  //     title: "select location",
  //     options: [{ value: 1, label: 'lorem' }, { value: 2, label: 'ipsum' }, { value: 3, label: 'dolor' }]
  //   },
  //   {
  //     searchState: availability,
  //     stateModifier: setAvailability,
  //     title: "select availability",
  //     options: [{ value: 1, label: 'available' }, { value: 2, label: 'not available' }]
  //   },
  //   {
  //     searchState: inviteOnlyMode,
  //     stateModifier: setInviteOnlyMode,
  //     title: "select invite only mode",
  //     options: [{ value: true, label: 'active' }, { value: false, label: 'inactive' }],
  //   },
  // ];

  const topDropdownItems = [
    {
      title: "export to csv",
      func: exportToCSV,
      icon: <i className="fa-solid fa-file-export"></i>,
    },
    {
      title: "send email",
      func: sendEmail,
      icon: <i class="fa-solid fa-envelope"></i>,
    },
  ];

  if (loading) {
    return <Loading />
  }

  if (error) {
    return <Error message={error?.message} />
  }

  let test


  console.log(test);


  return (
    <>

      <EditStaffModal
        showModal={showEditModal}
        setShowModal={setShowEditModal}
        id={staffID}

      />
      {/* <DisableStaffModal
        showModal={showDisableModal}
        setShowModal={setShowDisableModal}
      /> */}

      <DeleteStaffModal
        showModal={showDeleteModal}
        setShowModal={setShowDeleteModal}
        id={staffID}

      />
      <div className="p-4 ">
        <div className="flex justify-between items-center">
          <button
            onClick={() => setShowRegModal(true)}
            className=" bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 mt-2 mb-4"
          >
            Register Staff <i className="fa-solid fa-address-card ml-2"></i>
          </button>
          <TableActionDropdown itemsArr={topDropdownItems} />
        </div>

        <div className="p-4 bg-white m-2 drop-shadow-md rounded-md">
          <div className="flex items-center ml-2 mt-2 mb-5 ">
            <label htmlFor="">Show</label>
            <select className="mx-1 bg-transparent p-3 outline-none text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block cursor-pointer">
              {[50, 200, 500, 1000].map((value) => (
                <option>{value}</option>
              ))}
            </select>
            <label htmlFor="">entries</label>
          </div>
          <button
            className="uppercase text-lightblue border-none outline-none underline mb-2 p-2"
            onClick={() => setDisplayFilters(!displayFilters)}
          >
            {!displayFilters
              ? "display search parameters"
              : "hide search parameters"}
          </button>
          {displayFilters && (
            <div className="mb-6">
              <h3 className="text-dark font-semibold text-xl mx-2">
                Filter Visitors
              </h3>
              <div className="flex flex-wrap mt-2">
                {filterItems.map(
                  ({ searchState, stateModifier, title, options }) => (
                    <div className="w-1/5 min-w-max mx-2 mb-2" key={title}>
                      <p className="capitalize font-normal text-dark">
                        {title}
                      </p>
                      <SearchableDropdown
                        options={options}
                        selectedOption={searchState}
                        setSelectedOption={stateModifier}
                      />
                    </div>
                  )
                )}
              </div>

              <div className="flex items-center justify-between my-2">
                <button className="px-4 py-2 bg-lightblue font-semibold border-none outline-none block w-[20%] text-white rounded-md hover:bg-blue">
                  Search
                </button>
                <div className="flex flex-col sm:flex-row my-4 w-max items-center ">
                  <span className="mr-1">Search:</span>
                  <input
                    type="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="p-1 sm:p-2 px-3 bg-transparent rounded-md border border-light border-solid outline-none"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4  justify-center p-2 bg-white rounded-md drop-shadow-sm mt-4">
          {data.staffs.map(
            ({
              id,
              // img,
              first_name,
              last_name,
              is_available,
              position,
              department,
              phoneNumber,
              email,
              staff_ID
            }) => {



              return (
                <StaffCard
                  id={id}
                  img={avatar}
                  name={`${first_name} ${last_name}`}
                  availability={is_available}
                  title={position}
                  phoneNumber={phoneNumber}
                  email={email}
                  department={department}
                  key={id}
                  setShowDeleteModal={setShowDeleteModal}
                  setShowEditModal={setShowEditModal}
                  setShowDisableModal={setShowDisableModal}
                  staff_ID={staff_ID}
                  staffID={staffID}
                  setStaffID={setStaffID}

                />
              );
            }
          )}
        </div>

        <div className="flex justify-between text-dark bg-white my-4 rounded-md p-3 drop-shadow-sm">
          <p>Showing 0 to 0 entries</p>
          <div className="flex">
            {["first", "previous", "next", "last"].map((btn) => (
              <p className="capitalize mx-2" key={btn}>
                {btn}
              </p>
            ))}
          </div>
        </div>

        <RegisterStaffModal
          refresh={refresh}
          setRefresh={setRefresh}
          showModal={showRegModal}
          setShowModal={setShowRegModal}
        />
      </div>
    </>
  );
};

export default Staff;
