import Table from "../../components/tables/Table";
import { blacklistData } from "../../data";
import { useState } from 'react';
import { useNavigate } from "react-router-dom";
import RemoveFromBlacklistModal from "../../components/modals/RemoveFromBlacklistModal";
import useFetch from "../../hooks/useFetch";
import Loading from "../../components/Loading";
import Error from "../../components/Error";

const Blacklist = () => {
  const [id, setId] = useState("")

  const [signedInVisitors, setSignedInVisitors] = useState("");
  const [purpose, setPurpose] = useState("");
  const [selectHost, setSelectHost] = useState("");
  const [selectLocation, setSelectLocation] = useState("");
  const [displayFilters, setDisplayFilters] = useState(false);
  const [showActionDropdown, setShowActionDropdown] = useState(false);

  const [showBlacklistModal, setShowBlacklistModal] = useState(false)

  const navigate = useNavigate()

  const filterItems = [
    {
      searchState: signedInVisitors,
      stateModifier: setSignedInVisitors,
      title: "signed in visitors",
      options: ["lorem", "ipsum", "dolor"],
    },
    {
      searchState: purpose,
      stateModifier: setPurpose,
      title: "purpose",
      options: [{ value: 1, label: 'lorem' }, { value: 2, label: 'ipsum' }, { value: 3, label: 'dolor' }],
    },
    {
      searchState: selectHost,
      stateModifier: setSelectHost,
      title: "select host",
      options: [{ value: 1, label: 'lorem' }, { value: 2, label: 'ipsum' }, { value: 3, label: 'dolor' }],
    },
    {
      searchState: selectLocation,
      stateModifier: setSelectLocation,
      title: "select location",
      options: [{ value: 1, label: 'lorem' }, { value: 2, label: 'ipsum' }, { value: 3, label: 'dolor' }],
    },
  ];

  const viewProfile = (data) => {
    navigate(`/visitor-log/${data.id}`)

  };

  const removeFromBlacklist = (data) => {
    setShowBlacklistModal(true)
    setId(data.id)

  };



  const exportToCSV = () => {
    console.log("export to csv");
  };

  const bulkDelete = () => {
    console.log("bulk delete");
  };

  const actionColItems = [
    { title: "view profile", func: (visitorId) => viewProfile(visitorId) },
    { title: "remove from blacklist", func: (visitorId) => removeFromBlacklist(visitorId) },
  ];

  const topDropdownItems = [
    { title: "export to csv", func: exportToCSV, icon: <i className="fa-solid fa-file-export"></i> },
    { title: "bulk delete", func: bulkDelete, icon: <i className="fa-solid fa-trash"></i> },
  ];

  const { loading, error, data } = useFetch("visitor/blacklist", []);

  if (loading) {
    return <Loading />;
  }

  if (error) {
    return <Error message={error?.message} />;
  }

  return (
    <div className="p-4">
      <Table
        data={data.data}
        headings={[
          "name",
          "phone number",
          "email",
          "company",
          "last visit date",
          "action",
        ]}
        fieldsKeys={[
          "name",
          "phone_number",
          "email",
          "company",
          "updatedAt",
          "action",
        ]}
        filterItems={filterItems}
        actionColDropdownItems={actionColItems}
        topDropdownItems={topDropdownItems}
        displayFilters={displayFilters}
        setDisplayFilters={setDisplayFilters}
        title={"Blacklist"}
      />

      <RemoveFromBlacklistModal showModal={showBlacklistModal} setShowModal={setShowBlacklistModal} id={id} />
    </div>
  );
};

export default Blacklist;
