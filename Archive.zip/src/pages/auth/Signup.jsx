import { useState } from "react";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import AuthLayout from "../../components/auth/AuthLayout";
import { Api } from "../../axios";
import ButtonSpinner from "../../components/ButtonSpinner";
import { signup } from "../../services/auth";

const Signup = () => {
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [companyName, setCompanyName] = useState("");
  // const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [submitting, setSubmitting] = useState(false);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();

    setSubmitting(true);

    try {
      await signup({ companyName, email, firstname, lastname, password })

      toast.success("Account created successfully!.")
      toast.success("Account verification link sent to your mail!.");
      navigate("/login");
    } catch (error) {
      toast.error(error.message || error.response.data.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthLayout>
      <div className="sm:w-1/2 p-2 w-full">
        <div className="w-4/5 mx-auto block max-w-[500px] text-center sm:text-left">
          <h2 className=" text-4xl text-black font-bold mb-1">Join us</h2>

          <p className="text-md text-dark font-semibold mb-2">
            Hello! Please enter your details to join us.
          </p>
        </div>

        <form
          className="w-4/5 mx-auto block max-w-[500px]"
          onSubmit={handleSignup}
        >
          <div className="mb-4 flex w-full space-between">
            <div className=" flex-1">
              <label htmlFor="name" className="font-semibold text-black">
                First Name
              </label>
              <input
                type="text"
                value={firstname}
                className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
                onChange={(e) => setFirstname(e.target.value)}
                placeholder="Enter first name"
              />
            </div>
            <div className="ml-3 flex-1">
              <label htmlFor="name" className="font-semibold text-black">
                Last Name
              </label>
              <input
                type="text"
                value={lastname}
                className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
                onChange={(e) => setLastname(e.target.value)}
                placeholder="Enter last name"
              />
            </div>
          </div>

          <div className="mb-4">
            <label htmlFor="companyName" className="font-semibold text-black">
              Company name
            </label>
            <input
              type="text"
              value={companyName}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="Enter your company name"
            />
          </div>

          {/* <div className="mb-4">
            <label htmlFor="phoneNumber" className="font-semibold text-black">
              Phone number
            </label>
            <input
              type="tel"
              value={phoneNumber}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="Enter your phone number"
            />
          </div> */}

          <div className="mb-4">
            <label htmlFor="email" className="font-semibold text-black">
              Email
            </label>
            <input
              type="email"
              value={email}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
            />
          </div>

          <div className=" mb-4">
            <label htmlFor="password" className="font-semibold text-black">
              Password
            </label>
            <input
              type={"password"}
              value={password}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
            />
          </div>

          {/* {[].map(({ searchState, stateModifier, title, options }) => (
            <div className="w-1/5 min-w-[150px] mx-2 mb-2" key={options}>
              <p className="capitalize font-normal text-dark">{title}</p>
              <SearchableDropdown
                options={options}
                selectedOption={searchState}
                setSelectedOption={stateModifier}
              />
            </div>
          ))} */}

          {submitting ? (
            <ButtonSpinner />
          ) : (
            <button
              type="submit"
              className="w-full bg-lightblue py-3 rounded-md text-white hover:bg-blue text-lg  mt-3"
              onClick={handleSignup}
            >
              Signup
            </button>
          )}
        </form>

        <p className="text-center mt-5 text-dark">
          Have an account?
          <Link
            to="/login"
            className="px-1 font-semibold text-blue hover:underline"
          >
            Login
          </Link>
        </p>
      </div>
    </AuthLayout>
  );
};

export default Signup;
