import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/tables/Table";
import { companiesData } from "../../data";

const Companies = () => {
  const [status, setStatus] = useState("");
  const [country, setCountry] = useState("");
  const [usecase, setUsecase] = useState("");
  const [displayFilters, setDisplayFilters] = useState(false);
  const [showActionDropdown, setShowActionDropdown] = useState(false);

  const navigate = useNavigate()

  const filterItems = [
    {
      searchState: status,
      stateModifier: setStatus,
      title: "status",
      options: ["lofdfrem", "isum", "dolr"],
    },
    {
      searchState: country,
      stateModifier: setCountry,
      title: "country",
      options: ["lorem", "ipum", "dolr"],
    },
    {
      searchState: usecase,
      stateModifier: setUsecase,
      title: "use case",
      options: ["lordfm", "ipsum", "dolor"],
    },
  ];

  const view = (companyId) => {
    navigate(`/companies/${companyId}`)
  };

  const disableAccess = () => {
    console.log("disable access");
  };

  const enableSubscription = () => {
    console.log("disable access");
  };

  const extendFreeTrial = () => {
    console.log("disable access");
  };

  const exportToCSV = () => {
    console.log("export to csv");
  };

  const bulkDelete = () => {
    console.log("bulk delete");
  };

  const actionColItems = [
    { title: "view", func: (companyId) => view(companyId) },
    { title: "disable access", func: disableAccess },
    { title: "enable subscription", func: enableSubscription },
    { title: "extend free trial", func: extendFreeTrial },
  ];

  const topDropdownItems = [
    {
      title: "export to csv",
      func: exportToCSV,
      icon: <i className="fa-solid fa-file-export"></i>,
    },
    {
      title: "bulk delete",
      func: bulkDelete,
      icon: <i className="fa-solid fa-trash"></i>,
    },
  ];

  return (
    <div className="p-4">
      <Table
        data={companiesData}
        filterItems={filterItems}
        actionColDropdownItems={actionColItems}
        topDropdownItems={topDropdownItems}
        displayFilters={displayFilters}
        setDisplayFilters={setDisplayFilters}
        showActionDropdown={showActionDropdown}
        setShowActionDropdow={setShowActionDropdown}
        title={"Companies"}
        filterTitle={'Companies'}
      />
    </div>
  );
};

export default Companies;
