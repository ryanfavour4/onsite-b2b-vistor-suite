import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../features/authSlice";
import settingsReducer from "../features/settingsSlice";
import profileReducer from "../features/profileSlice";

const store = configureStore({
  reducer: {
    auth: authReducer,
    settings: settingsReducer,
    profile: profileReducer,
  },
});

export default store;
