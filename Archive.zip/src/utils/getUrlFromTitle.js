const getUrlFromTitle = (title) => {
  return title.split(" ").join("-");
};
export default getUrlFromTitle;
