export const getDateFromTimestamp = (timestamp) => {
  console.log(timestamp)
  const date = new Date(`${timestamp}`);

  const day = date.getDate();
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "July",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  if (month && day && year)
    return `${month} ${day}, ${year}`;

  return 'N/A'
};

export const getTimeFromTimestamp = (timestamp) => {
  // const new Date().to
  return new Date(`${timestamp}`).toLocaleTimeString();
};

export const formatMonthDigit = (digit) => {
  if (digit > 9) {
    return `${digit}`;
  } else {
    return `0${digit}`;
  }
};

export const getYMDFormat = (date) => {
  // console.log(date)

  return `${date.getFullYear()}-${formatMonthDigit(date.getMonth() + 1)}-${formatMonthDigit(date.getDate())}`
}