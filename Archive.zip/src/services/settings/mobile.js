export const editMobileConfig = async = (data) => {

}