import { Api } from "../axios";
import {
  validateEmail,
  validateEmailAndPassword,
  validateName,
  validatePassword,
} from "../utils/validate";

export const login = async (email, password) => {
  validateEmailAndPassword(email, password);
  try {
    const res = await Api.post("users/sign-in", {
      email: email.trim(),
      password,
    });
    console.log("ress", res);
    return res.data;
  } catch (error) {
    // if (error?.response?.data?.message) {
    //   throw new Error(error.response.data.message);
    // }
    // throw new Error(error.message);
  }
};

export const superAdminLogin = async (email, password) => {
  validateEmailAndPassword(email, password);
  try {
    const res = await Api.post("admin/login", {
      email: email.trim(),
      password,
    });
    console.log("ress", res);

    // return res.data;
    return res;
  } catch (error) {
    if (error?.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    throw new Error(error.message);
  }
};

export const resetPassword = async (data) => {
  validatePassword(data.newPassword, "new password");
  validatePassword(data.confirmPassword, "confirm password");
  validatePassword(data.email, "email");
  try {
    const res = await Api.post("users/change-password", data);
  } catch (error) {
    if (error?.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    throw new Error(error.message);
  }
};

export const requestOtp = async (email) => {
  validateEmail(email);
  try {
    const res = await Api.post("users/forgotpassword", {
      email,
    });
    return res.data;
  } catch (error) {
    if (error?.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    throw new Error(error.message);
  }
};

export const signup = async (data) => {
  const { companyName, email, firstname, lastname, password, phoneNumber } =
    data;

  validateEmailAndPassword(email, password);
  try {
    await Api.post("users/sign-up", {
      company_name: companyName,
      email: email,
      password: password,
      last_name: lastname,
      first_name: firstname,
      option: "office",
      country: 156,
      phone_number: phoneNumber,
    });
  } catch (error) {
    if (error?.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    throw new Error(error.message);
  }
};

export const resendEmail = async (email) => {
  validateEmail(email, "email");
  try {
    await Api.post("users/resend-token", { email });
  } catch (error) {
    if (error?.response?.data?.message) {
      throw new Error(error.response.data.message);
    }
    throw new Error(error.message);
  }
};

export const getUserDetails = async (token) => {
  try {
    const res = await Api.get("users/current", {
      headers: { Authorization: `Bearer ${token}` },
    });

    console.log(res);
    return res;
  } catch (error) {
    console.log(error);
    return {};
  }
};

export const getAdminDetails = async (token) => {
  try {
    const res = await Api.get("admin/current", {
      token: token,
    });

    console.log(res);
    return res;
  } catch (error) {
    console.log(error);
    return {};
  }
};
