import { useDispatch, useSelector } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import PrivateRoutes from "./routes/PrivateRoutes/PrivateRoutes";
import PublicRoutes from "./routes/PublicRoutes";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useEffect, useLayoutEffect, useState } from "react";
import { setAxiosToken } from "./axios";
import { authenticate } from "./features/authSlice";
import Loading from "./components/Loading";
import { getAdminDetails, getUserDetails } from "./services/auth";
import { subscribeUser } from './subscription';

function App() {
  const { userData } = useSelector((state) => state.auth);

  console.log(userData);
  const [loading, setLoading] = useState(true);

  const dispatch = useDispatch();

  useLayoutEffect(
    () => {

      (async () => {
        if (!("Notification" in window)) {
          console.log("This browser does not support desktop notification");
        } else {
          Notification.requestPermission().then(result => {
            console.log(result);
          });
          console.log("Notifications are supported");
        }
        try {
          if (localStorage.getItem("auth") != null) {
            const otherRes = await getUserDetails(JSON.parse(localStorage.getItem("auth")).userData.token)
            dispatch(authenticate({ userData: JSON.parse(localStorage.getItem("auth")).userData, staffInviteOnlyMode: Boolean(otherRes.data.user?.appointment_only), companyInviteOnlyMode: Boolean(Number(otherRes.data.user?.company_invite_mode)) }))
          }
          setLoading(true)
        } catch (error) {
          console.log(error)
          setLoading(false)

        } finally {
          setLoading(false)
        }
      })()
    }, []
  )



  if (loading) {
    return <Loading />
  }

  return (
    <Router>


      {/* <button onClick={subscribeUser} className="bg-blue text-white rounded-md p-4 absolute top-40 left-20 z-[1000]">Click Here</button> */}
      <ToastContainer />
      {userData != null ? <PrivateRoutes /> : <PublicRoutes />}
    </Router>
  );
}

export default App;
