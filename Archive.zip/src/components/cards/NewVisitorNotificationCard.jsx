import React from 'react'
import { useNavigate } from 'react-router-dom'
import avatar from '../../assets/defaultAvatar.png'

const NewVisitorNotificationCard = ({id, newVisitorNotifications, setNewVisitorNotifications}) => {
    const navigate = useNavigate()
  return (
    <div className='flex items-center p-2 border border-light rounded-sm'>

        <div className='w-20 h-20 mr-2 rounded-sm'>
            <img src={avatar} className='h-full w-full object-fit rounded-sm '/>
        </div>

        <div>
            <p className='text-black text-xs bg-lightred w-max px-1 py-0.5'>
                New Visitor
            </p>
            <p className='my-1 text-sm'>
                Felix Ogunbiade
            </p>
            <p className='text-xs'>
                Pz cussions Ltd.
            </p>
            <div className='text-xs mt-1'>
                <button className='bg-lightblue text-white hover:bg-blue p-1 rounded-sm mr-2' onClick={() => navigate('/visitor-ebadge')}>
                    View Profile
                </button>
                <button className='bg-darkred text-white hover:bg-blue p-1 rounded-sm mr-2' onClick={() => setNewVisitorNotifications(newVisitorNotifications.filter(
                    (notification) => {
                        return notification.id !== id
                    }
                ))}>
                    Dismiss
                </button>
            </div>
        </div>
    </div>
  )
}

export default NewVisitorNotificationCard