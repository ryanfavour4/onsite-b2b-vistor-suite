import { useState, useEffect } from "react";
import Required from "../Required";
import SearchableDropdown from "../dropdowns/SearchableDropdown";
import CloseModalBtn from "./CloseModalBtn";
import Success from "../Success";
import { toast } from "react-toastify";
import { Api } from "../../axios";
import useFetch from "../../hooks/useFetch";
import { staffsData } from "../../data";

const EditStaffModal = ({ showModal, setShowModal, id }) => {
  const [load, setLoad] = useState(false);
  const [staffDetails, setStaffDetails] = useState({});
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [staffPhoto, setStaffPhoto] = useState("");
  const [address, setAddress] = useState("");
  const [position, setPosition] = useState("");
  const [staffID, setStaffID] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [locations, setLocations] = useState([])
  const [staffPositions, setStaffPositions] = useState([])
  const [departments, setDepartments] = useState([])
  const [department, setDepartment] = useState([])

  const [firstAssistant, setFirstAssistant] = useState({});


  const [assistants, setAssistants] = useState([])
  const [officeLocation, setOfficeLocation] = useState({});





  const assistantOptions = useFetch("settings/get-all-staffs", [showModal]);
  const locationOptions = useFetch('settings/view-location', [showModal])
  const staffPositionOptions = useFetch('settings/position', [showModal])
  const departmentOptions = useFetch('settings/get-department', [showModal])





  useEffect(() => {
    // console.log(locationOptions.data, 'location dataaa')
    setLocations(locationOptions?.data?.locations.map(
      ({ id, name }) => ({ value: id, label: name }
      )))
  }, [locationOptions.data])


  useEffect(() => {
    console.log(assistantOptions.data, 'staffs dataaa')
    setAssistants(assistantOptions?.data?.staffs.map(
      ({ id, first_name, last_name }) => ({ value: id, label: `${first_name} ${last_name}` }
      )))
  }, [assistantOptions.data])

  useEffect(() => {
    // console.log(staffPositionOptions.data, 'staff positions dataaa')
    setStaffPositions(staffPositionOptions?.data?.data?.map(
      ({ id, position }) => ({ value: id, label: position }
      )))
  }, [staffPositionOptions.data])

  console.log(position);



  useEffect(() => {
    // console.log(departmentOptions.data, 'department dataaa')
    setDepartments(departmentOptions?.data?.data.map(
      ({ id, department }) => ({ value: id, label: department }
      )))
  }, [departmentOptions.data])




  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await Api.get(`settings/get-staff/${id}`);
        const staffData = response.data?.staff;
        console.log(staffData);


        if (staffData) {
          setStaffDetails(staffData);
          setFirstname(staffData.first_name);
          setLastname(staffData.last_name);
          setPhoneNumber(staffData.phone_number);
          setEmail(staffData.email);
          setDepartment(staffData.department?.value);
          setStaffID(staffData.staff_ID);
          setAddress(staffData.address);
          setPosition(staffData.position?.value);
          setLoad(true);
        }

        console.log(staffData?.position);

      } catch (error) {
        console.log(error);
      }
    };

    if (showModal) {
      fetchData();
    }
  }, [showModal, id]);

  const logDetails = {
    email: email,
    last_name: lastname,
    first_name: firstname,
    department: department,
    phone_number: phoneNumber,
    staff_ID: staffID,
    address: address,
    position: position,
    is_available: true,
    location: locations
  }

  console.log(logDetails);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      await Api.put(`settings/update-staff/${id}`, {
        email: email,
        last_name: lastname,
        first_name: firstname,
        department: department,
        phone_number: phoneNumber,
        staff_ID: staffID,
        address: address,
        position: position,
        is_available: true,
        location: 1
      });


      setShowSuccess(true);
      window.location.reload()
    } catch (error) {
      toast.error(error.response || error.response);
      console.log(error);
    } finally {
      setSubmitting(false);
    }
  };



  return (
    <div className={`${showModal ? "modal" : "hidden"}`}>
      {showSuccess ? (
        <Success
          message={"Staff details updated successfully!"}
          setShowSuccess={setShowSuccess}
          setShowParentModal={setShowModal}
        />
      ) : (
        <form onSubmit={handleSubmit} className="relative modal--content">
          <CloseModalBtn setShowModal={setShowModal} />

          <div className="mb-3">
            <label htmlFor="privateNote" className="font-semibold text-black">
              Staff photo
            </label>
            <input
              type="file"
              value={staffPhoto}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setStaffPhoto(e.target.value)}
              placeholder="upload staff photo"
            />
          </div>

          <div className="mb-4 flex">
            <div>
              <label htmlFor="name" className="font-semibold text-black">
                First Name
              </label>
              <input
                type="text"
                value={firstname}
                className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
                onChange={(e) => setFirstname(e.target.value)}
                placeholder="Enter first name"
              />
            </div>
            <div className="ml-3">
              <label htmlFor="name" className="font-semibold text-black">
                Last Name
              </label>
              <input
                type="text"
                value={lastname}
                className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
                onChange={(e) => setLastname(e.target.value)}
                placeholder="Enter last name"
              />
            </div>
          </div>

          <div className="mb-4">
            <label htmlFor="staffId" className="font-semibold text-black">
              Staff ID
            </label>
            <input
              type="text"
              value={staffID}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setStaffID(e.target.value)}
              placeholder="Enter staff ID"
            />
          </div>

          <div className="mb-4">
            <label htmlFor="phoneNumber" className="font-semibold text-black">
              Phone number
              <Required />
            </label>
            <div className="flex">
              <select className="mr-2 rounded-lg p-2 bg-transparent border-solid border-[1px] border-lightestblue focus:border-blue block">
                {["+234", "+212", "+27", "+251"].map((option) => (
                  <option value={option} key={option}>
                    {option}
                  </option>
                ))}
              </select>
              <input
                type="tel"
                value={phoneNumber}
                className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="123 4567 89"
              />
            </div>
          </div>

          <div className="mb-4">
            <label htmlFor="email" className="font-semibold text-black">
              Email
            </label>
            <input
              type="email"
              value={email}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter staff email"
            />
          </div>

          <div className="mb-4">
            <label htmlFor="department" className="font-semibold text-black">
              Department
            </label>
            <select
              name=""
              id="department"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full capitalize"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
            >
              {departments?.map(({ value, label }) => (
                <option value={value} key={value}>
                  {label}
                </option>
              ))}
            </select>


          </div>

          <div className="mb-4">
            <label htmlFor="position" className="font-semibold text-black">
              Position
            </label>
            <select
              name=""
              id="position"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full capitalize"
              value={position}
              onChange={(e) => setPosition(e.target.value)}
            >
              {staffPositions?.map(({ value, label }) => (
                <option value={value} key={value}>
                  {label}
                </option>
              ))}
            </select>



          </div>

          <div className="mb-4">
            <label htmlFor="address" className="font-semibold text-black">
              Address
            </label>
            {/* <select
              name=""
              id="address"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full capitalize"
            >
              {["lofem", "ipsum", "dolor"].map((item) => (
                <option value={item}>{item}</option>
              ))}
            </select> */}

            <input
              type="address"
              value={address}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter staff address"
            />
          </div>

          <div className="mb-4">
            <label
              htmlFor="officeLocation"
              className="font-semibold text-black"
            >
              Office location
            </label>
            <select
              name=""
              id="officeLocation"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full capitalize"
              value={officeLocation}
              onChange={(e) => setOfficeLocation(e.target.value)}
            >
              {locations?.map(({ value, label }) => (
                <option value={value} key={value}>
                  {label}
                </option>
              ))}
            </select>

          </div>

          <div className="mb-4">
            <label htmlFor="assistant" className="font-semibold text-black">
              Assistant++
            </label>
            <select
              name=""
              id="assistant"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full capitalize"
              value={firstAssistant}
              onChange={(e) => setFirstAssistant(e.target.value)}
            >
              {assistants?.map(({ value, label }) => (
                <option value={value} key={value}>
                  {label}
                </option>
              ))}
            </select>

          </div>

          {/* 
          <button
            type="submit"
            className="w-full bg-lightblue py-3 rounded-md text-white hover:bg-blue text-lg font-nunito mt-3"
            onClick={handleSubmit}
          >
            Update staff details
          </button> */}

          {submitting ? (
            <button
              type="button"
              className="w-full bg-lightestblue py-3 rounded-md text-lg  mt-3"
              disabled
            >
              <svg
                class="animate-spin h-5 w-5 mr-3 ..."
                viewBox="0 0 24 24"
              ></svg>
              Submitting...
            </button>
          ) : (
            <button
              type="submit"
              className="w-full bg-lightblue py-3 rounded-md text-white hover:bg-blue text-lg  mt-3"
              onClick={handleSubmit}
            >
              Update Staff
            </button>
          )}
        </form>
      )}
    </div>
  );
};

export default EditStaffModal;
