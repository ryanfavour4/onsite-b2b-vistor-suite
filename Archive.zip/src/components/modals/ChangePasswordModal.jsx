import { useEffect, useState } from "react";
import Required from "../Required";
import SearchableDropdown from "../dropdowns/SearchableDropdown";
import CloseModalBtn from "./CloseModalBtn";
import Success from "../Success";
import ButtonSpinner from "../ButtonSpinner";
import { Api } from "../../axios";
import { toast } from "react-toastify";
import { changePassword, editStaff } from "../../services/staff";
import useFetch from "../../hooks/useFetch";

const ChangePasswordModal = ({ showModal, setShowModal }) => {
  const [showSuccess, setShowSuccess] = useState(false);
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [submitting, setSubmitting] = useState(false)


  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setSubmitting(true);
      await changePassword({
        oldPassword,
        newPassword,
        confirmPassword
      })
      setShowSuccess(true);
    } catch (error) {
      toast.error(error.message || error.data.message);
    } finally {
      setSubmitting(false)
    }

  };


  return (
    <div className={`${showModal ? "modal" : "hidden"}`}>
      {showSuccess ? (
        <Success
          message={"Password updated successfully!"}
          setShowSuccess={setShowSuccess}
          setShowParentModal={setShowModal}
        />
      ) : (
        <form onSubmit={handleSubmit} className="relative modal--content h-32">
          <CloseModalBtn setShowModal={setShowModal} />

          <div className=" mb-4">
            <label htmlFor="password" className="font-semibold text-black">
              Old password
            </label>
            <input
              type={"password"}
              value={oldPassword}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setOldPassword(e.target.value)}
              placeholder="Enter old password"
            />
          </div>

          <div className=" mb-4">
            <label htmlFor="password" className="font-semibold text-black">
              New password
            </label>
            <input
              type={"password"}
              value={newPassword}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Enter new password"
            />
          </div>

          <div className=" mb-4">
            <label htmlFor="password" className="font-semibold text-black">
              Confirm password
            </label>
            <input
              type={"password"}
              value={confirmPassword}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Enter confirm password"
            />
          </div>

          {
            submitting ?
              <ButtonSpinner />
              :
              <button
                type="submit"
                className="w-full bg-lightblue py-3 rounded-md text-white hover:bg-blue mt-1 text-sm"
                onClick={handleSubmit}
              >
                Update password
              </button>
          }

        </form>
      )}
    </div>
  );
};

export default ChangePasswordModal;
