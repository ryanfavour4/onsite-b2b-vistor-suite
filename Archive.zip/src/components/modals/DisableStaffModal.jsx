import CloseModalBtn from "./CloseModalBtn";

const DisableModal = ({ showModal, setShowModal }) => {

  return (
    <div className={`${showModal ? 'modal' : 'hidden'} `}>
      <div className="relative modal--content flex items-center justify-center">
        <CloseModalBtn setShowModal={setShowModal} />

        <div className="h-max w-max p-2 text-center">
        <p className="mb-6 text-black text-xl">
            Are you sure you want to disable this staff from receiving visitors?
        </p>
        <div className="flex justify-between max-w-[150px] mx-auto capitalize">
            <button className="text-white px-4 py-2 bg-green rounded-md capitalize" onClick={() => setShowModal(false)}>
                yes
            </button>
            <button className="text-white px-4 py-2 bg-darkred rounded-md capitalize" onClick={() => setShowModal(false)}>
                no
            </button>
        </div>
        </div>

      </div>
    </div>
  );
};

export default DisableModal;
