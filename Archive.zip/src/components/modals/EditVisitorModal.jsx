import { useEffect, useState } from "react";
import CloseModalBtn from "./CloseModalBtn";
import Success from "../Success";
import { Api } from "../../axios";
import useFetch from "../../hooks/useFetch";

const EditVisitorModal = ({ showModal, setShowModal, id }) => {
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState(null);
  const [emailAddress, setEmailAddress] = useState("");
  const [address, setAddress] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [purpose, setPurpose] = useState([])

  const [visitorPhoto, setVisitorPhoto] = useState(null);

  const [showSuccess, setShowSuccess] = useState(false);



  const purposeOptions = useFetch("settings/visit-purpose", [showModal]);

  useEffect(() => {
    // console.log(purposeOptions.data.data, 'purpose dataaa')
    setPurpose(purposeOptions?.data?.data.map(
      ({ id, visit_purpose_name }) => ({ value: id, label: ` ${visit_purpose_name}` }
      )))
  }, [purposeOptions.data])





  // purpose?.map((e, i) => {
  //   console.log(e);
  // })


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await Api.get(`visitor/${id}`);

        const visitorData = response.data?.data;
        console.log(visitorData.phone_number);


        if (visitorData) {

          setName(visitorData.name)
          setPhoneNumber(visitorData.phone_number)
          setEmailAddress(visitorData.email)
          setAddress(visitorData.address)
          setCompanyName(visitorData.company)
          setPurpose(visitorData.purpose)
        }



      } catch (error) {
        console.log(error);
      }
    };

    if (showModal) {
      fetchData();
    }
  }, [showModal, id, name]);

  const handleSubmit = () => {
    // console.log("handle submit");

    try {

      const editVisitor = async () => {

        Api.get(`visitor/${id}`);

      }

    } catch (error) {

      console.log(error);

    }


    setShowSuccess(true);
  };

  return (
    <div
      className={`${showModal ? "modal" : "hidden"} text-sm`}
    >
      {showSuccess ? (
        <Success
          message={"Visitor details updated successfully!"}
          setShowSuccess={setShowSuccess}
          setShowParentModal={setShowModal}
        />
      ) : (
        <form onSubmit={handleSubmit} className="relative modal--content">
          <CloseModalBtn setShowModal={setShowModal} />
          <div className="mb-3">
            <label htmlFor="name" className="font-semibold text-black ">
              Name
            </label>
            <input
              type="text"
              value={name}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter visitor name"
            />
          </div>

          <div className="mb-4">
            <label htmlFor="phoneNumber" className="font-semibold text-black">
              Phone number
            </label>
            <div className="flex">
              <select className="mr-2 rounded-lg p-2 bg-transparent border-solid border-[1px] border-lightestblue focus:border-blue block">
                {["+234", "+212", "+27", "+251"].map((option) => (
                  <option value={option} key={option}>
                    {option}
                  </option>
                ))}
              </select>
              <input
                type="tel"
                value={phoneNumber}
                className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="123 4567 89"
              />
            </div>
          </div>


          <div className="mb-3">
            <label htmlFor="emailAddress" className="font-semibold text-black">
              Email Address
            </label>
            <input
              type="email"
              value={emailAddress}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setEmailAddress(e.target.value)}
              placeholder="Enter visitor email address"
            />
          </div>

          <div className="mb-4">
            <label htmlFor="assistant" className="font-semibold text-black">
              Purpose
            </label>
            <select
              name=""
              id="assistant"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full capitalize"
            >
              {Array.isArray(purpose) && purpose.map(({ value, label }) => (
                <option value={value} key={value}>
                  {label}
                </option>
              ))}

            </select>
          </div>

          <div className="mb-3">
            <label htmlFor="companyName" className="font-semibold text-black">
              Company name
            </label>
            <input
              type="text"
              value={companyName}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="Enter company name"
            />
          </div>

          <div className="mb-3">
            <label htmlFor="address" className="font-semibold text-black">
              Address
            </label>
            <input
              type="text"
              value={address}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter address"
            />
          </div>

          <div className="mb-3">
            <label htmlFor="privateNote" className="font-semibold text-black">
              Private note
            </label>
            <textarea
              name="privateNote"
              id="privateNote"
              cols="4"
              rows="3"
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
            ></textarea>
          </div>

          <div className="mb-3">
            <label htmlFor="privateNote" className="font-semibold text-black">
              Visitor photo
            </label>
            <input
              type="file"
              value={visitorPhoto}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setVisitorPhoto(e.target.value)}
              placeholder="upload visitor photo"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-lightblue py-3 rounded-md text-white hover:bg-blue mt-1 text-sm"
            onClick={handleSubmit}
          >
            Update Visitor details
          </button>
        </form>


      )}
    </div>
  );
};

export default EditVisitorModal;
