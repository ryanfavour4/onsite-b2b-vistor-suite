import { useEffect, useState } from "react";
import Required from "../Required";
import SearchableDropdown from "../dropdowns/SearchableDropdown";
import CloseModalBtn from "./CloseModalBtn";
import Success from "../Success";
import ButtonSpinner from "../ButtonSpinner";
import { Api } from "../../axios";
import { toast } from "react-toastify";
import { editStaff } from "../../services/staff";
import useFetch from "../../hooks/useFetch";

const EditProfileModal = ({ showModal, setShowModal, data, refresh, setRefresh }) => {
  const [showSuccess, setShowSuccess] = useState(false);
  const [firstname, setFirstname] = useState(data.first_name)
  const [lastname, setLastname] = useState(data.last_name);
  const [email, setEmail] = useState(data.email);
  const [phone, setPhone] = useState(data.phone_number);
  const [staffPosition, setStaffPosition] = useState(data.position)
  const [address, setAddress] = useState(data.address)

  const [staffPositions, setStaffPositions] = useState([])

  const [submitting, setSubmitting] = useState(false)

  const staffPositionOptions = useFetch('settings/position', [showModal])





  console.log(data)


  useEffect(() => {
    console.log(staffPositionOptions.data, 'staff positions dataaa')
    setStaffPositions(staffPositionOptions?.data?.data?.map(
      ({ id, position }) => ({ value: id, label: position }
      )))
  }, [staffPositionOptions.data])



  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setSubmitting(true);
      await editStaff(data.id, {
        email: email,
        last_name: lastname,
        first_name: firstname,
        phone_number: phone,
        staff_position: staffPosition.value,
        address: address
      })
      setShowSuccess(true);
    } catch (error) {
      toast.error(error.message || error.data.message);
    } finally {
      setSubmitting(false)
    }

  };

  console.log(staffPosition);


  return (
    <div className={`${showModal ? "modal" : "hidden"}`}>
      {showSuccess ? (
        <Success
          message={"Profile details updated successfully!"}
          setShowSuccess={setShowSuccess}
          setShowParentModal={setShowModal}
          refresh={refresh}
          setRefresh={setRefresh}
        />
      ) : (
        <form onSubmit={handleSubmit} className="relative modal--content h-32">
          <CloseModalBtn setShowModal={setShowModal} />

          <div className="mb-3">
            <label htmlFor="firstname" className="font-semibold text-black capitlize ">
              First name
            </label>
            <input
              type="text"
              value={firstname}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setFirstname(e.target.value)}
              placeholder="Enter firstname"
            />
          </div>

          <div className="mb-3">
            <label htmlFor="lastname" className="font-semibold text-black ">
              Last name
            </label>
            <input
              type="text"
              value={lastname}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setLastname(e.target.value)}
              placeholder="Enter lastname"
            />
          </div>

          <div className="mb-3">
            <label htmlFor="email" className="font-semibold text-black ">
              Email address
            </label>
            <input
              type="email"
              value={email}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter email address"
            />
          </div>

          <div className="mb-3">
            <label htmlFor="phone" className="font-semibold text-black ">
              Phone number
            </label>
            <input
              type="tel"
              value={phone}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Enter phone number"
            />
          </div>

          <div className="mb-3">
            <label htmlFor="staffPosition" className="font-semibold text-black ">
              Staff position
            </label>
            <SearchableDropdown
              loading={staffPositionOptions.loading}
              options={staffPositions}
              selectedOption={staffPosition}
              setSelectedOption={setStaffPosition}

            />
          </div>

          <div className="mb-3">
            <label htmlFor="staffPosition" className="font-semibold text-black ">
              Address
            </label>
            <input
              type="text"
              value={address}
              className="bg-transparent p-3 outline-none flex-1 text-black rounded-lg border-solid border-[1px] border-lightestblue focus:border-blue block w-full"
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter address"
            />
          </div>

          {
            submitting ?
              <ButtonSpinner />
              :
              <button
                type="submit"
                className="w-full bg-lightblue py-3 rounded-md text-white hover:bg-blue mt-1 text-sm"
                onClick={handleSubmit}
              >
                Update profile details
              </button>
          }

        </form>
      )}
    </div>
  );
};

export default EditProfileModal;
