const Required = () => {
  return (
    <span className='text-darkred mx-1 '>
        *
    </span>
  )
}

export default Required