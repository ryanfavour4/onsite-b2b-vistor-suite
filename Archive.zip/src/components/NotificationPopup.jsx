import React from "react";
import { useState } from "react";
import { useRef } from "react";
import { Link } from "react-router-dom";
import { notificationData } from "../data";
import useOutsideListener from "../hooks/useOutsideListener";
import NewVisitorNotificationCard from "./cards/NewVisitorNotificationCard";
import NotificationCard from "./cards/NotificationCard";

const NotificationPopup = ({ setShowPopup }) => {
  const wrapperRef = useRef(null);
  useOutsideListener(wrapperRef, () => setShowPopup(false));

  const [notifications, setNotifications] = useState(notificationData);
  const [newVisitorNotifications, setNewVisitorNotifications] = useState([
    { id: 1 },
    { id: 2 },
  ]);
  return (
    <div
      className="absolute top-16 rounded-md  bg-lightest border-2 border-solid  border-lightest z-10 min-h-32 min-w-full w-max right-0 border border-light h-max"
      ref={wrapperRef}
    >
      <div className="flex justify-between p-4 bg-white rounded-t-md">
        <h2>Notifications</h2>
        <button>
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <button className="ml-auto block mt-2 px-4 text-sm" onClick={() => {
        setNotifications([])
        setNewVisitorNotifications([])
        }}>Clear all</button>

      <div className="p-2">
        {notifications.map(({ title, description, time, id }) => (
          <NotificationCard
            title={title}
            description={description}
            time={time}
            notifications={notifications}
            setNotifications={setNotifications}
            id={id}
          />
        ))}
      </div>

      {newVisitorNotifications.map(({ id }) => (
        <NewVisitorNotificationCard
          id={id}
          setNewVisitorNotifications={setNewVisitorNotifications}
          newVisitorNotifications={newVisitorNotifications}
        />
      ))}

      <Link
        to="/notification"
        className="text-blue underline mt-6 text-center block "
      >
        View all
      </Link>
    </div>
  );
};

export default NotificationPopup;
