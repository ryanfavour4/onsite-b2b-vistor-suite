import React from 'react'

const SubscriptionHistory = () => {
  return (
    <div>SubscriptionHistory</div>
  )
}

export default SubscriptionHistory