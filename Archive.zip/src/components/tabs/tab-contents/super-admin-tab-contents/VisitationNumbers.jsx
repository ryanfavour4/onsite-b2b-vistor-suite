import React from 'react'

const VisitationNumbers = () => {
  return (
    <div>VisitationNumbers</div>
  )
}

export default VisitationNumbers