import React from 'react'

const AllStaffs = () => {
  return (
    <div>AllStaffs</div>
  )
}

export default AllStaffs