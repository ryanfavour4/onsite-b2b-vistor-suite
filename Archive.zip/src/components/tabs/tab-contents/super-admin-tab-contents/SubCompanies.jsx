import React from 'react'

const SubCompanies = () => {
  return (
    <div>SubCompanies</div>
  )
}

export default SubCompanies