import React from "react";
import { useState } from "react";
import { branchFieldsData } from "../../../../data";
import useFetch from "../../../../hooks/useFetch";
import Error from "../../../Error";
import Loading from "../../../Loading";
import CreateBranchModal from "../../../modals/CreateBranchModal";
import Table from "../../../tables/Table";

const Branch = () => {
  const [showBranchModal, setShowBranchModal] = useState(false);
  const [refresh, setRefresh] = useState(false)

  const editLocation = () => { };
  const deleteLocation = () => { };
  const actionColItems = [
    { title: "edit", func: editLocation },
    { title: "delete", func: deleteLocation },
  ];

  const { data, loading, error } = useFetch('settings/branch', [refresh])

  if (loading) {
    return <Loading />
  }

  if (error) {
    return <Error message={error?.message} />;
  }


  return (
    <>
      <div>
        <Table
          data={data.branches}
          headings={['Branch ID', 'Name of branch', 'branch address', 'country', 'branch admin', 'action']}
          fieldsKeys={['id', 'branch_name', 'branch_address', 'country', 'branch_email', 'action']}
          actionColDropdownItems={actionColItems}
          setDisplayFilters={"setDisplayFilters"}
          showActionDropdown={"showActionDropdown"}
          setShowActionDropdown={"setShowActionDropdown"}
          title={"Branch"}
        >
          <button
            onClick={() => setShowBranchModal(true)}
            className="mx-2 bg-lightblue hover:bg-blue text-white drop-shadow-md rounded-md p-2 flex justify-center items-center px-4 pmt-2../"
          >
            Create new branch
          </button>
        </Table>

      </div>
      <CreateBranchModal
        refresh={refresh}
        setRefresh={setRefresh}
        showModal={showBranchModal}
        setShowModal={setShowBranchModal}
      />
    </>
  );
};

export default Branch;
