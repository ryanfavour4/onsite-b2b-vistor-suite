import { visitationHistoryData } from "../../../../data"
import Table from "../../../tables/Table"

const VisitationHistory = () => {
  return (
    <div>
      <Table
        data={visitationHistoryData.data}
        // data={[]}
        headings={[
          "date",
          "visitor name",
          "email",
          "phone number",
          "purpose of visit",
          "sign in",
          "sign out",
          "duration of stay",
        ]}
        // headings={[]}
        fieldsKeys={[
          "date",
          "visitorName",
          "email",
          "phoneNumber",
          "purposeOfVisit",
          "signIn",
          "signOut",
          "durationOfStay",
        ]}
        // data={visitationHistoryData}
        actionColDropdownItems={[]}
        topDropdownItems={[]}
        showActionDropdown={'showActionDropdown'}
        setShowActionDropdow={'setShowActionDropdown'}
        title={"Visitation history"}
      />
    </div>
  )
}

export default VisitationHistory